<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>show</title>
</head>
<body>
<?php
require_once 'config.php';
require_once 'db_config.php';
$connection=databaseConnect();
$sql = "SELECT text,image FROM qr_code ORDER BY text";
$result = mysqli_query($connection, $sql) or die(mysqli_error($connection));

if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
    {
        echo '<p>';
        echo $row['text'];
        echo '<img src="codes/'.$row['image'].'" alt="'.$row['text'].'">';
    }
}
?>
</body>
</html>