<!DOCTYPE html>
<html>
<head>
    <title>Kollokvium</title>
</head>
<body>

<form action="create_code.php" method="post">
    <label for="text">Text: </label><br>
    <input type="text" id="text" name="text"><br>
    <input type="submit" value="Submit">
    <input type="button" value="Cancel">
</form>
</body>
</html>
