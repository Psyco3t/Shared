<?php

if(empty($_POST['text']) or !isset($_POST['text'])){
    //echo 'he';
    header("Location:form.php?r=1");
    exit();
}

require_once 'config.php';
require_once 'db_config.php';
require_once 'phpqrcode/qrlib.php';

$connection=databaseConnect();
$text=mysqli_real_escape_string($connection,$_POST['text']);
$hash="";

for($i=0;$i<5;$i++)
{
    $hash.=mt_rand(0,9);
}

$hash=sha1($hash);

$sql = "INSERT INTO qr_code(text,hash) VALUES ('$text','$hash')";
mysqli_query($connection, $sql) or die(mysqli_error($connection));

$id_qr_code=mysqli_insert_id($connection);

$FileName = md5(time()).".png";
$pngAbsoluteFilePath = DIRPATH . $FileName;
//"scan.php?code=$random_num";
$code = LINK . "scan.php?id=$id_qr_code&h=$hash";
QRcode::png($code, $pngAbsoluteFilePath,QR_ECLEVEL_L, 8);

$sql = "UPDATE qr_code SET image='$FileName' WHERE id_qr_code='$id_qr_code'";
mysqli_query($connection, $sql) or die(mysqli_error($connection));