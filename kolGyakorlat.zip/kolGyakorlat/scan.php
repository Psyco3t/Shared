<?php
require_once 'config.php';
require_once 'db_config.php';
require_once 'functions.php';
$connection=databaseConnect();

$id=0;
$h="";

if(isset($_GET['id']) and isset($_GET['h'])){
    $id_qr_code=(int)$_GET['id'];
    $hash=mysqli_real_escape_string($connection,$_GET['h']);
}
$id_qr_code=8;
$hash="64bf2b648417752cad0cbdb8f7dd0eba5079ba4a";
$sql="SELECT id_qr_code FROM qr_code WHERE id_qr_code='$id_qr_code' and hash='$hash'";
$result=mysqli_query($connection,$sql) or die(mysqli_error($connection));

if(mysqli_num_rows($result)==0){
    $sql="INSERT INTO error_log(id,hash) VALUES ($id_qr_code,'$hash')";
    mysqli_query($connection,$sql) or die(mysqli_error($connection));

    echo "<p> No valid data! </p>";
    exit();
}
//unset($_COOKIE);
if(!isset($_COOKIE['SCAN']))
{
    require_once 'Mobile-Detect-2.8.39/Mobile_Detect.php';
    $detect=new Mobile_Detect();
    $deviceType=($detect->isMobile() ? $detect->isTablet() ? 'phone': 'tablet' : 'computer');
    $ipaddress=getIpAddress();
    $userAgent=$_SERVER['HTTP_USER_AGENT'];
    $accept=$_SERVER['HTTP_ACCEPT'];
    $sql="INSERT INTO scan_log(id_qr_code,http_user_agent,http_accept,ip_address,device_type)
    VALUES ('$id_qr_code','$userAgent','$accept','$ipaddress','$deviceType')";
    mysqli_query($connection,$sql) or die(mysqli_error($connection));

    setcookie('SCAN',md5('TRUE'),strtotime('+20 minutes'),"","",false,true);
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Death</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div>
            <h1>QR CODE</h1>
        </div>
    </div>
    <div class="row">
        <div><img src="kep.png" alt="logo" width="70px" height="50px"></div>
    </div>
    <div>
        <h1 class="display-1">
            <div>
            <?php
            $sql = "SELECT text,image FROM qr_code ORDER BY text";
            $result = mysqli_query($connection, $sql) or die(mysqli_error($connection));

            if(mysqli_num_rows($result)>0){
                while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
                {
                    echo '<div>';
                    echo $row['id']." ".$row['hash']." ".$row['date_time']." ";
                    echo '</div>';
                }
            }
            ?>
            </div>
        </h1>
    </div>
    <div class="row">
        <div>qr code</div>
        <div>data</div>
        <?php
        ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>
</html>
