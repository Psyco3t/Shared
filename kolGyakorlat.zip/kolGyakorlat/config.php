<?php
define("PARAMS", [ //connection params as array
   "HOST"=>"localhost",
   "USER"=>"root",
   "PASSWORD"=>"",
   "DATABASE"=>"emob"
]);

//echo PARAMS("HOST"); print out host const

define("FOLDERROUTE", "/iws/kolGyakorlat/");
define("NGROK", "https://e8f1-147-91-199-142.ngrok.io");
define("LINK", NGROK.FOLDERROUTE);
define('DIRPATH','codes/');